
const express = require('express');
const app = express();
app.use(express.json());

app.get('/api/products', (req,res)=>{
    res.json([{id:1,name:'Sample Decor Item',price:299}]);
});

app.listen(4000, ()=> console.log('Backend running on port 4000'));
